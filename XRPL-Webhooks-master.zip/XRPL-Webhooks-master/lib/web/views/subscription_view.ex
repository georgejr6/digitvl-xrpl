
defmodule EspyWeb.SubscriptionView do
  use EspyWeb, :view
  alias EspyWeb.SubscriptionView

end
