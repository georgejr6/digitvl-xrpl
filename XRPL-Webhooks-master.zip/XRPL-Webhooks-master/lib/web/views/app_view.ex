defmodule EspyWeb.AppView do
  use EspyWeb, :view

end
