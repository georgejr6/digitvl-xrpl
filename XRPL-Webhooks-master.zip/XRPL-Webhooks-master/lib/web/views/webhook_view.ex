
defmodule EspyWeb.WebhookView do
  use EspyWeb, :view

end
