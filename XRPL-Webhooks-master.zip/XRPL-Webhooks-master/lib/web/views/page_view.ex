defmodule EspyWeb.PageView do
  use EspyWeb, :view
end
