defmodule EspyWeb.LayoutView do
  use EspyWeb, :view
end
